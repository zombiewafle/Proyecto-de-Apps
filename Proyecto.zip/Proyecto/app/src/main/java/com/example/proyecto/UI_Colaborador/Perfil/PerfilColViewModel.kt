package com.example.proyecto.UI_Colaborador.Perfil

import androidx.lifecycle.ViewModel

class PerfilColViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}