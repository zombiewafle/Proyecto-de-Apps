package com.example.proyecto.UI_Colaborador.Oportunidades

import androidx.lifecycle.ViewModel

class OpColViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}